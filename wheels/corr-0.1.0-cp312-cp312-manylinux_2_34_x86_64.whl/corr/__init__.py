from .corr import *

__doc__ = corr.__doc__
if hasattr(corr, "__all__"):
    __all__ = corr.__all__